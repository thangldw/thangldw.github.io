Branch protection requires review and passing status checks.
