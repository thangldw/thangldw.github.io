# Maintainer Defense example

Illustrative local fixture with one intentionally excessive workflow permission.
Do not deploy this workflow.

Run: maintainer-defense audit maintainer-defense-example

The fixture is derived from the project test corpus. No workflow or repository code is executed by the auditor.
