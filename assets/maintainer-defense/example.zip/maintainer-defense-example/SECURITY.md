Report vulnerabilities privately through GitHub Security Advisories.
